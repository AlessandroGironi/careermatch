Evaluate the candidate fit for the job.

CV TEXT:
{cv_text}

JOB DESCRIPTION TEXT:
{job_text}
