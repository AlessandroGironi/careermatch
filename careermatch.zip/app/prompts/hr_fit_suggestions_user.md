FIT ANALYSIS JSON:
{fit_core_json}

CV TEXT:
{cv_text}

JOB DESCRIPTION TEXT:
{job_text}
